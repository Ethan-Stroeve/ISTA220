﻿namespace Parameters
{
    class WrappedInt
    {
        public int Number;
        public string IdontKnow;
        public bool isTrue;
    }
}
